// components/SearchBar.js
import React from 'react';

const SearchBar = () => {
  return (
    <div className="bg-blue-900 p-2 flex justify-center items-center relative">
      <div className="bg-white rounded-full flex items-center relative w-full max-w-md">
        <select id="patients" className="appearance-none bg-gray-300 border border-gray-300 px-3 py-2 rounded-l-full  text-gray-900 text-sm">
          <option value="all">Patients</option>
          <option value="john-doe">John Doe</option>
          <option value="jane-smith">Jane Smith</option>
          {/* Add more patient options as needed */}
        </select>
        <input type="text" placeholder=" Search" className="pl-3 pr-10 py-2 border border-gray-300 rounded-r-full focus:outline-none focus:border-blue-500 flex-grow text-sm" />
        <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
          <svg className="h-5 w-5 text-gray-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M15.293 13.707a1 1 0 0 1-1.414 1.414l-3-3a1 1 0 1 1 1.414-1.414l3 3zM10 17a7 7 0 1 1 0-14 7 7 0 0 1 0 14z" clipRule="evenodd" />
          </svg>
        </div>
      </div>
      <div className="ml-2">
      <button className="bg-green-700 text-white px-4 py-2 rounded-full hover:bg-blue-600 text-sm">+ Add New</button>
      </div>
      <div className="absolute top-1/2 right-16 transform -translate-y-1/2">
      <div className="rounded-full bg-gray-600 w-8 h-8 flex justify-center items-center ml-2">
        <img src="https://www.pinclipart.com/picdir/big/369-3699390_notification-png-notification-icon-png-free-clipart.png" alt="Notification Icon" className="h-5 w-5" />
        </div>
      </div>
      <div className="absolute top-1/2 right-4 transform -translate-y-1/2">
      <div className="rounded-full bg-gray-600 w-8 h-8 flex justify-center items-center ml-2">
        <img src="https://www.bing.com/th?id=OIP.BVzB-kwofFUZTWkZRpPZaQAAAA&w=150&h=225&c=8&rs=1&qlt=90&o=6&dpr=1.5&pid=3.1&rm=2" alt="Profile icon" className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
};

export default SearchBar;
