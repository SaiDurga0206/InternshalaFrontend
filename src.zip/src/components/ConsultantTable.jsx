import React from 'react';
import { FaArrowDown, FaArrowRight } from 'react-icons/fa';

const ConsultantTable = () => {
  return (
    <div className="bg-white p-4 mb-4">
        <div className="flex items-center justify-between mb-2">
        <h2 className="text-lg font-semibold mb-4 text-gray-600">Consultants</h2>
        <div className="flex">
        <div className="rounded-full bg-gray-300 p-2 mr-4">
            <FaArrowRight className="text-gray-600 text-xl" />
          </div>
          <div className="rounded-full bg-gray-300 p-2">
            <FaArrowDown className="text-gray-600 text-xl" />
          </div>
        </div>
      </div>
      <table className="w-full border border-gray-400 table-auto">
      <colgroup>
          <col style={{ width: '25%' }} />
          <col style={{ width: '25%' }} />
          <col style={{ width: '25%' }} />
          <col style={{ width: '25%' }} />
        </colgroup>
        <thead>
          <tr className="bg-white">
            <th className="px-4 py-4 border border-gray-400 text-gray-600">NAME</th>
            <th className="px-4 py-4 border border-gray-400 text-gray-600">PATIENT COUNT</th>
            <th className="px-4 py-4 border border-gray-400 text-gray-600">LABS</th>
            <th className="px-4 py-4 border border-gray-400 text-gray-600">DIET PLANS</th>
          </tr>
        </thead>
        <tbody>
          {/* Sample data */}
          <tr>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">John Smith</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">12</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">3</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">6</td>
          </tr>
          <tr>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">Jane Doe</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">8</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">2</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">4</td>
          </tr>
          <tr>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">Mark Johnson</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">6</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">1</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">2</td>
          </tr>
          <tr>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">Mary Lee</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">10</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">4</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">8</td>
          </tr>
          <tr>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">David Chen</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">14</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">5</td>
            <td className="border border-gray-400 px-4 py-4 text-center text-gray-600">9</td>
          </tr>
          
          {/* End of sample data */}
        </tbody>
      </table>
     
    </div>
  );
};

export default ConsultantTable;
