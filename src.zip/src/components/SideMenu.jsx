import React from 'react';
import { MdPerson, MdWork, MdLocalHospital, MdLocalPharmacy, MdAssignment, MdAssignmentInd, MdAssessment, MdPayment } from 'react-icons/md';

const SideMenu = () => {
  return (
    <div className="fixed top-20 left-8 bg-white h-full w-56">
      <div className="p-2">
        <h2 className="text-gray-700 text-lg font-semibold mb-1">Dashboards</h2>
        <div className="bg-white rounded-lg shadow-md p-2 mb-2 flex flex-col items-center">
          <MdPerson className="text-gray-800 text-lg" />
          <p className="text-gray-600">Patients</p>
        </div>
        <div className="bg-green-800 rounded-lg shadow-md p-2 mb-2 flex flex-col items-center">
          <MdWork className="text-white text-lg" />
          <p className="text-white">HR</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-2 mb-2 flex flex-col items-center">
          <MdLocalHospital className="text-gray-800 text-lg" />
          <p className="text-gray-600">Labs</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-2 mb-2 flex flex-col items-center">
          <MdLocalPharmacy className="text-gray-800 text-lg" />
          <p className="text-gray-600">Pharma</p>
        </div>
      </div>
      <div className="p-2">
        <h2 className="text-gray-700 text-lg font-semibold mb-1">Processes</h2>
        <div className="bg-white rounded-lg shadow-md p-2 mb-2 flex flex-col items-center">
          <MdAssignmentInd className="text-gray-800 text-lg" />
          <p className="text-gray-600">Registration</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-2 mb-2 flex flex-col items-center">
          <MdAssessment className="text-gray-800 text-lg" />
          <p className="text-gray-600">Consultation</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-2 mb-2 flex flex-col items-center">
          <MdAssignment className="text-gray-800 text-lg" />
          <p className="text-gray-600">Tests & Reports</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-2 mb-2 flex flex-col items-center">
          <MdPayment className="text-gray-800 text-lg" />
          <p className="text-gray-600">Billing</p>
        </div>
      </div>
    </div>
  );
};

export default SideMenu;
