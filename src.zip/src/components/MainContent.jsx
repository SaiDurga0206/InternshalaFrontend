// components/MainContent.js
import React from 'react';
import { FaUsers, FaCalendarAlt, FaFlask, FaDollarSign } from 'react-icons/fa';
import ConsultantTable from './ConsultantTable';

const MainContent = () => {
  return (
    <div className="ml-64 bg-gray-100 h-screen">
    <div className="p-4">
      <h1 className="text-xl font-semibold mb-4 flex items-center">
        <FaUsers className="text-gray-600 text-xl mr-2" />
        consultants
      </h1>
      <div className="flex space-x-4">
      <button className="flex-grow bg-green-800 text-white p-3 relative rounded-full">
            <div className="absolute top-0 right-0 p-1">
              {/* Comment symbol */}
                <path fillRule="evenodd" d="M15 2a3 3 0 013 3v7a3 3 0 01-3 3H9.414l-4 4H3a1 1 0 01-1-1V5a3 3 0 013-3h10zm0 2H5a1 1 0 00-1 1v8h1.586L8 15.414l1.707-1.707A1 1 0 0010 13H15a1 1 0 001-1V5a1 1 0 00-1-1zm-2 6a1 1 0 100 2h-4a1 1 0 100-2h4z" clipRule="evenodd" />
            </div>
            Filters
          </button>
        <div className="flex-grow bg-white p-3 relative rounded">
          <select className="block w-full px-3 py-1 border rounded-full  focus:outline-none">
          <option value="this-week">Select Range</option>
            <option value="this-week">This Week</option>
            <option value="last-week">Last Week</option>
            <option value="this-month">This Month</option>
            <option value="last-month">Last Month</option>
          </select>
        </div>
        <button className="flex-grow bg-white p-1  rounded-full hover:bg-gray-200">⚪ Summary</button>
        <button className="flex-grow bg-white p-1  rounded-full hover:bg-gray-200">⚪ Branch Wise</button>
      </div>
    </div>
      {/* Consultant Stats */}
      <div className="bg-gray-200 p-4 mb-4">
        <div className="flex flex-row gap-4">
        <div className="bg-white rounded-lg shadow-md p-4 flex-1 flex items-center justify-between border-l-4 border-orange-200">
            <div>
            <p className="text-green-900 text-lg font-semibold mb-2">Consultant Count</p>
            <p className="text-gray-600 text-lg font-bold">90 / 900</p>
            <p className='text-gray-600'>Today/Period</p>
            </div>
            <div className="rounded-full bg-orange-200 p-2">
            <FaUsers className="text-gray-600 text-xl" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-md p-4 flex-1 flex items-center justify-between border-l-4 border-blue-400">
            <div>
            <p className="text-green-900 text-lg font-semibold mb-2">Consultations</p>
            <p className="text-gray-600 text-lg font-bold">11 / 25</p>
            <p className='text-gray-600'>Today/Period</p>
            </div>
            <div className="rounded-full bg-blue-200 p-2">
            <FaCalendarAlt className="text-gray-600 text-xl" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-md p-4 flex-1 flex items-center justify-between border-l-4 border-green-400">
            <div>
            <p className="text-green-900 text-lg font-semibold mb-2">Labs</p>
            <p className="text-gray-600 text-lg font-bold">25 / 560</p>
            <p className='text-gray-600'>Today/Period</p>
            </div>
            <div className="rounded-full bg-green-200 p-2">
            <FaFlask className="text-gray-600 text-xl" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-md p-4 flex-1 flex items-center justify-between border-l-4 border-purple-400">
            <div>
            <p className="text-green-900 text-lg font-semibold mb-2">DietPlans</p>
            <p className="text-gray-600 text-lg font-bold">25 / 250</p>
            <p className='text-gray-600'>Today/Period</p>
            </div>
            <div className="rounded-full bg-purple-200 p-2">
            <FaDollarSign className="text-gray-600 text-xl" />
            </div>
          </div>
        </div>
      </div>
      {/* End of Consultant Stats */}
      <ConsultantTable/>
    </div>
  );
};

export default MainContent;
