// components/Layout.js
import React from 'react';
import SearchBar from './SearchBar';
import SideMenu from './SideMenu';

const Layout = () => {
  return (
    <div className="grid grid-cols-1">
      <SearchBar/>
      <SideMenu/>
    </div>
  );
};

export default Layout;
