// App.js
import React from 'react';
// import SearchBar from './components/SearchBar';
import MainContent from './components/MainContent';
import SearchBar from './components/SearchBar';
import SideMenu from './components/SideMenu';
// import SideMenu from './components/SideMenu';
// import Layout from './components/Layout';

// import MainContent from './components/MainContent';

function App() {
  return (
    <div className="container mx-auto p-6">
     <SearchBar/>
     <SideMenu/>
      <MainContent/>
    </div>
  );
}

export default App;
